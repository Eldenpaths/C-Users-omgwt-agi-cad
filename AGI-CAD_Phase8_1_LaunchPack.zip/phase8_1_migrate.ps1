# AGI-CAD — Phase 8.1 App Router migration (Windows PowerShell)
# Run from repo root: C:\Users\omgwt\agi-cad

Write-Host "== Phase 8.1: App Router migration ==" -ForegroundColor Yellow

# 0) Stop on error
$ErrorActionPreference = "Stop"

# 1) Create app dirs
New-Item -ItemType Directory -Force -Path src\app\dashboard | Out-Null
New-Item -ItemType Directory -Force -Path src\app\agenthub | Out-Null

# 2) Move legacy pages (if they exist)
if (Test-Path pages\dashboard.jsx) { Move-Item pages\dashboard.jsx src\app\dashboard\page.jsx -Force }
if (Test-Path pages\agenthub.jsx) { Move-Item pages\agenthub.jsx src\app\agenthub\page.jsx -Force }
if (Test-Path pages\index.js) { Move-Item pages\index.js src\app\page.js -Force }

# 3) Remove /pages if empty or present
if (Test-Path pages) { Remove-Item -Recurse -Force pages }

# 4) Ensure layout + globals exist (do not overwrite)
if (-not (Test-Path src\app\layout.jsx)) {
  Copy-Item src\app\layout.jsx.sample src\app\layout.jsx -Force
}
if (-not (Test-Path src\app\globals.css)) {
  Copy-Item src\app\globals.css.sample src\app\globals.css -Force
}

# 5) Write configs if missing (keep user's files if already present)
if (-not (Test-Path next.config.js)) {
  Copy-Item next.config.js.sample next.config.js -Force
}
if (-not (Test-Path jsconfig.json)) {
  Copy-Item jsconfig.json.sample jsconfig.json -Force
}

# 6) Clean Next cache
if (Test-Path .next) {
  Write-Host "Cleaning .next cache..." -ForegroundColor DarkGray
  Remove-Item -Recurse -Force .next
}

Write-Host "Migration complete. Run: pnpm dev" -ForegroundColor Green
