# AGI-CAD Core Phase 8.1 — App Router Baseline & Forge UI Integration

**Context**
App Router migration complete. Target: validate `/`, `/dashboard`, `/forge`, `/agenthub` render without alias errors. Then integrate Forge telemetry + visualization.

**Next actions**
1. Run `pnpm dev` and verify routes.
2. Hook mock heartbeat → Firebase `buildEvents`.
3. Implement Forge core (Spherical Harmonics pulse, WGSL particle compute).
4. LOD & perf (Grok pass).

**Artifacts**
- Config: `next.config.js`, `jsconfig.json` (baseUrl=src, @/* alias)
- Layout & theme: `src/app/layout.jsx`, `src/app/globals.css`
- Panels: `src/components/forge/{AgentPanel, VaultPanel}`
