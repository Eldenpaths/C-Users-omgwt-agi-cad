# AGI-CAD Core — Phase 8.1 Launch Pack
**Date:** 2025-10-27T07:55:54.692344Z

This pack locks the *App Router baseline* and the Forge UI integration plan.

---

## What this pack contains
- `README_PHASE8.1.md` — this document
- `phase8_1_migrate.ps1` — one-shot migration script for Windows/PowerShell
- `next.config.js.sample` — canonical Next.js config (App Router on)
- `jsconfig.json.sample` — alias configuration (`@/*` → `src/*`)
- `src/app/layout.jsx.sample` — root layout scaffold (Forge theme wrapper)
- `src/app/globals.css.sample` — theme tokens + Tailwind hooks
- `NEW_THREAD_SEED.md` — header to start the next thread cleanly

> ⚠️ **Safety:** These are *samples*. Copy/merge into your repo as needed.
> Always `Remove-Item -Recurse -Force .next` after config moves.

---

## Success criteria (Phase 8.1)
1) Pure App Router project layout (no `/pages` folder)
2) Routes load with no alias errors:
   - `/` (home) — basic text OK
   - `/dashboard` — dashboard shell renders
   - `/forge` — forge page renders (can be stub/placeholder)
   - `/agenthub` — page renders (stub is fine)
3) Aliases work from anywhere using `@/…`
4) One-click clean: `Remove-Item -Recurse -Force .next` then `pnpm dev`

---

## Canonical tree (post-migration)

```
agi-cad/
├─ src/
│  ├─ app/
│  │  ├─ layout.jsx
│  │  ├─ globals.css
│  │  ├─ page.js
│  │  ├─ dashboard/
│  │  │  └─ page.jsx
│  │  ├─ forge/
│  │  │  └─ page.tsx
│  │  └─ agenthub/
│  │     └─ page.jsx
│  ├─ components/
│  │  ├─ Layout.jsx
│  │  └─ forge/
│  │     ├─ AgentPanel.tsx
│  │     └─ VaultPanel.tsx
│  ├─ hooks/
│  │  └─ useAuth.js
│  └─ lib/
│     └─ vault.js
├─ next.config.js
├─ jsconfig.json
└─ package.json
```

---

## Apply in your repo (quick path)

1. **Stop dev server** if running (`Ctrl + C`)
2. **Run the migration script** in repo root:
   ```powershell
   .\phase8_1_migrate.ps1
   ```
3. **Start dev server**:
   ```powershell
   pnpm dev
   ```
4. Visit:
   - http://localhost:3000
   - http://localhost:3000/dashboard
   - http://localhost:3000/forge
   - http://localhost:3000/agenthub

If you see any 404/500 caused by stale cache, run:
```powershell
Remove-Item -Recurse -Force .next
pnpm dev
```

---

## Next focus (Phase 8.2 – Live Forge)
- Hook mock heartbeat → Firebase `buildEvents`
- R3F core: Spherical Harmonics pulse (shader)
- GPU compute (WGSL) for particle physics
- Agent orbits: Keplerian parametric motion
- LOD + perf pass (Grok-style)
